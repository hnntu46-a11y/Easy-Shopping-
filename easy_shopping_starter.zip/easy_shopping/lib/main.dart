import 'package:flutter/material.dart';

void main() => runApp(const EasyShoppingApp());

const brand = Color(0xFF6750E8);
const ink = Color(0xFF202033);

class EasyShoppingApp extends StatelessWidget {
  const EasyShoppingApp({super.key});
  @override
  Widget build(BuildContext context) => MaterialApp(
        title: 'Easy Shopping',
        debugShowCheckedModeBanner: false,
        theme: ThemeData(
          useMaterial3: true,
          colorScheme: ColorScheme.fromSeed(seedColor: brand),
          scaffoldBackgroundColor: const Color(0xFFF8F7FC),
          appBarTheme: const AppBarTheme(backgroundColor: Color(0xFFF8F7FC), foregroundColor: ink),
        ),
        home: const StoreShell(),
      );
}

class Product {
  Product(this.name, this.category, this.price, this.emoji, this.color, {this.oldPrice});
  final String name, category, emoji;
  final double price;
  final double? oldPrice;
  final Color color;
}

final products = <Product>[
  Product('Everyday Sneakers', 'Fashion', 1299, '👟', const Color(0xFFE8E2FF), oldPrice: 1799),
  Product('Wireless Headphones', 'Electronics', 1899, '🎧', const Color(0xFFFFE7D9), oldPrice: 2499),
  Product('Classic Backpack', 'Accessories', 899, '🎒', const Color(0xFFDDF5E8)),
  Product('Smart Watch', 'Electronics', 2299, '⌚', const Color(0xFFFFE4EF), oldPrice: 2999),
  Product('Skin Care Set', 'Beauty', 699, '🧴', const Color(0xFFFFF0C9)),
  Product('Coffee Mug', 'Home', 299, '☕', const Color(0xFFDDEBFF)),
  Product('Casual T-Shirt', 'Fashion', 499, '👕', const Color(0xFFE3F4F4)),
  Product('Mini Speaker', 'Electronics', 999, '🔊', const Color(0xFFF1E0FF)),
];

class StoreShell extends StatefulWidget {
  const StoreShell({super.key});
  @override
  State<StoreShell> createState() => _StoreShellState();
}

class _StoreShellState extends State<StoreShell> {
  int tab = 0;
  final cart = <Product>[];
  final favourites = <Product>{};
  @override
  Widget build(BuildContext context) {
    final pages = [
      HomePage(cart: cart, favourites: favourites, onChanged: () => setState(() {}), onAdmin: () => Navigator.push(context, MaterialPageRoute(builder: (_) => const AdminPage()))),
      CartPage(cart: cart, onChanged: () => setState(() {})),
      WishlistPage(favourites: favourites, onChanged: () => setState(() {})),
      const AccountPage(),
    ];
    return Scaffold(
      body: SafeArea(child: pages[tab]),
      bottomNavigationBar: NavigationBar(
        selectedIndex: tab,
        onDestinationSelected: (v) => setState(() => tab = v),
        destinations: const [
          NavigationDestination(icon: Icon(Icons.home_outlined), selectedIcon: Icon(Icons.home), label: 'Home'),
          NavigationDestination(icon: Icon(Icons.shopping_cart_outlined), selectedIcon: Icon(Icons.shopping_cart), label: 'Cart'),
          NavigationDestination(icon: Icon(Icons.favorite_border), selectedIcon: Icon(Icons.favorite), label: 'Wishlist'),
          NavigationDestination(icon: Icon(Icons.person_outline), selectedIcon: Icon(Icons.person), label: 'Account'),
        ],
      ),
    );
  }
}

class HomePage extends StatefulWidget {
  const HomePage({super.key, required this.cart, required this.favourites, required this.onChanged, required this.onAdmin});
  final List<Product> cart;
  final Set<Product> favourites;
  final VoidCallback onChanged, onAdmin;
  @override
  State<HomePage> createState() => _HomePageState();
}
class _HomePageState extends State<HomePage> {
  String category = 'All';
  String query = '';
  final categories = const ['All', 'Fashion', 'Electronics', 'Accessories', 'Beauty', 'Home'];
  @override
  Widget build(BuildContext context) {
    final shown = products.where((p) => (category == 'All' || p.category == category) && p.name.toLowerCase().contains(query.toLowerCase())).toList();
    return CustomScrollView(slivers: [
      SliverToBoxAdapter(child: Padding(padding: const EdgeInsets.fromLTRB(20, 14, 20, 8), child: Row(children: [
        Container(width: 46, height: 46, decoration: BoxDecoration(color: brand, borderRadius: BorderRadius.circular(15)), child: const Icon(Icons.shopping_cart_rounded, color: Colors.white, size: 27)),
        const SizedBox(width: 11), const Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [Text('Easy Shopping', style: TextStyle(fontSize: 21, fontWeight: FontWeight.w900, color: ink)), Text('Everything you love, in one place', style: TextStyle(fontSize: 11, color: Colors.black54))])),
        IconButton(onPressed: widget.onAdmin, tooltip: 'Admin demo', icon: const Icon(Icons.admin_panel_settings_outlined)),
      ]))),
      SliverToBoxAdapter(child: Padding(padding: const EdgeInsets.fromLTRB(20, 12, 20, 16), child: TextField(onChanged: (v) => setState(() => query = v), decoration: InputDecoration(hintText: 'Search products...', prefixIcon: const Icon(Icons.search), filled: true, fillColor: Colors.white, border: OutlineInputBorder(borderRadius: BorderRadius.circular(18), borderSide: BorderSide.none))))),
      SliverToBoxAdapter(child: Padding(padding: const EdgeInsets.symmetric(horizontal: 20), child: Container(padding: const EdgeInsets.all(20), decoration: BoxDecoration(gradient: const LinearGradient(colors: [Color(0xFF6C55EE), Color(0xFFEC6FB7)]), borderRadius: BorderRadius.circular(24)), child: Row(children: [Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [const Text('BIG STYLE.\nBETTER PRICES.', style: TextStyle(color: Colors.white, fontSize: 23, height: 1.1, fontWeight: FontWeight.w900)), const SizedBox(height: 8), const Text('Discover your next favourite thing.', style: TextStyle(color: Colors.white70, fontSize: 12)), const SizedBox(height: 13), FilledButton.tonal(onPressed: () => setState(() => category = 'All'), child: const Text('Shop now'))])), const Text('🛍️', style: TextStyle(fontSize: 67))])))),
      const SliverToBoxAdapter(child: Padding(padding: EdgeInsets.fromLTRB(20, 22, 20, 10), child: Text('Shop by category', style: TextStyle(fontWeight: FontWeight.w800, fontSize: 18, color: ink)))),
      SliverToBoxAdapter(child: SizedBox(height: 42, child: ListView.separated(padding: const EdgeInsets.symmetric(horizontal: 20), scrollDirection: Axis.horizontal, itemCount: categories.length, separatorBuilder: (_, __) => const SizedBox(width: 8), itemBuilder: (_, i) => ChoiceChip(label: Text(categories[i]), selected: category == categories[i], onSelected: (_) => setState(() => category = categories[i])))),
      SliverToBoxAdapter(child: Padding(padding: const EdgeInsets.fromLTRB(20, 22, 20, 12), child: Row(children: [const Expanded(child: Text('Popular right now', style: TextStyle(fontWeight: FontWeight.w800, fontSize: 18, color: ink))), Text('${shown.length} items', style: const TextStyle(color: Colors.black45, fontSize: 12))]))),
      SliverPadding(padding: const EdgeInsets.fromLTRB(16, 0, 16, 24), sliver: SliverGrid(delegate: SliverChildBuilderDelegate((context, i) => ProductCard(product: shown[i], isFavourite: widget.favourites.contains(shown[i]), onFavourite: () { setState(() { if (!widget.favourites.add(shown[i])) widget.favourites.remove(shown[i]); }); widget.onChanged(); }, onAdd: () { widget.cart.add(shown[i]); widget.onChanged(); ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('${shown[i].name} added to cart'), duration: const Duration(seconds: 1))); }), childCount: shown.length), gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(crossAxisCount: 2, mainAxisSpacing: 12, crossAxisSpacing: 12, childAspectRatio: .68))),
    ]);
  }
}

class ProductCard extends StatelessWidget {
  const ProductCard({super.key, required this.product, required this.isFavourite, required this.onFavourite, required this.onAdd});
  final Product product; final bool isFavourite; final VoidCallback onFavourite, onAdd;
  @override
  Widget build(BuildContext context) => Container(decoration: BoxDecoration(color: Colors.white, borderRadius: BorderRadius.circular(20), boxShadow: [BoxShadow(color: Colors.black.withOpacity(.035), blurRadius: 12, offset: const Offset(0, 5))]), child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
    Expanded(child: Stack(children: [Container(width: double.infinity, decoration: BoxDecoration(color: product.color, borderRadius: const BorderRadius.vertical(top: Radius.circular(20))), child: Center(child: Text(product.emoji, style: const TextStyle(fontSize: 64)))), Positioned(right: 7, top: 7, child: IconButton.filledTonal(onPressed: onFavourite, icon: Icon(isFavourite ? Icons.favorite : Icons.favorite_border, color: isFavourite ? Colors.pink : ink), visualDensity: VisualDensity.compact))])),
    Padding(padding: const EdgeInsets.fromLTRB(11, 10, 11, 11), child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [Text(product.category.toUpperCase(), style: const TextStyle(fontSize: 9, letterSpacing: 1.1, color: brand, fontWeight: FontWeight.w800)), const SizedBox(height: 4), Text(product.name, maxLines: 1, overflow: TextOverflow.ellipsis, style: const TextStyle(fontWeight: FontWeight.w700, fontSize: 13)), const SizedBox(height: 7), Row(children: [Text('₹${product.price.toStringAsFixed(0)}', style: const TextStyle(fontWeight: FontWeight.w900, fontSize: 15)), if (product.oldPrice != null) ...[const SizedBox(width: 5), Text('₹${product.oldPrice!.toStringAsFixed(0)}', style: const TextStyle(fontSize: 10, color: Colors.black38, decoration: TextDecoration.lineThrough))]]), const SizedBox(height: 8), SizedBox(width: double.infinity, child: FilledButton.icon(onPressed: onAdd, icon: const Icon(Icons.add_shopping_cart, size: 16), label: const Text('Add to cart'), style: FilledButton.styleFrom(padding: const EdgeInsets.symmetric(vertical: 8), textStyle: const TextStyle(fontSize: 11, fontWeight: FontWeight.w700))))]))
  ]));
}

class CartPage extends StatelessWidget {
  const CartPage({super.key, required this.cart, required this.onChanged}); final List<Product> cart; final VoidCallback onChanged;
  @override
  Widget build(BuildContext context) { final total = cart.fold<double>(0, (s, p) => s + p.price); return Scaffold(appBar: AppBar(title: const Text('Your Cart', style: TextStyle(fontWeight: FontWeight.w800))), body: cart.isEmpty ? const EmptyState(icon: Icons.shopping_cart_outlined, title: 'Your cart is waiting', subtitle: 'Add a few things you love!') : Column(children: [Expanded(child: ListView.builder(padding: const EdgeInsets.all(16), itemCount: cart.length, itemBuilder: (_, i) { final p = cart[i]; return Card(color: Colors.white, child: ListTile(leading: CircleAvatar(backgroundColor: p.color, child: Text(p.emoji, style: const TextStyle(fontSize: 23))), title: Text(p.name), subtitle: Text('₹${p.price.toStringAsFixed(0)}'), trailing: IconButton(icon: const Icon(Icons.delete_outline), onPressed: () { cart.removeAt(i); onChanged(); }))); })), Container(padding: const EdgeInsets.all(20), color: Colors.white, child: Column(children: [Row(mainAxisAlignment: MainAxisAlignment.spaceBetween, children: [const Text('Subtotal', style: TextStyle(fontSize: 16)), Text('₹${total.toStringAsFixed(0)}', style: const TextStyle(fontWeight: FontWeight.w900, fontSize: 20))]), const SizedBox(height: 12), SizedBox(width: double.infinity, child: FilledButton(onPressed: () => Navigator.push(context, MaterialPageRoute(builder: (_) => CheckoutPage(total: total))), child: const Text('Proceed to checkout')))]))])); }
}

class CheckoutPage extends StatefulWidget { const CheckoutPage({super.key, required this.total}); final double total; @override State<CheckoutPage> createState() => _CheckoutPageState(); }
class _CheckoutPageState extends State<CheckoutPage> { String payment = 'Cash on Delivery'; @override Widget build(BuildContext context) => Scaffold(appBar: AppBar(title: const Text('Checkout')), body: ListView(padding: const EdgeInsets.all(20), children: [const Text('Delivery address', style: TextStyle(fontWeight: FontWeight.w800, fontSize: 18)), const SizedBox(height: 10), const TextField(decoration: InputDecoration(labelText: 'Full name', border: OutlineInputBorder())), const SizedBox(height: 10), const TextField(decoration: InputDecoration(labelText: 'Phone number', border: OutlineInputBorder()), keyboardType: TextInputType.phone), const SizedBox(height: 10), const TextField(decoration: InputDecoration(labelText: 'Full delivery address', border: OutlineInputBorder()), maxLines: 3), const SizedBox(height: 24), const Text('Payment method', style: TextStyle(fontWeight: FontWeight.w800, fontSize: 18)), RadioListTile<String>(value: 'Cash on Delivery', groupValue: payment, onChanged: (v) => setState(() => payment = v!), title: const Text('Cash on Delivery'), secondary: const Icon(Icons.payments_outlined)), RadioListTile<String>(value: 'UPI / Online', groupValue: payment, onChanged: (v) => setState(() => payment = v!), title: const Text('UPI / Online payment'), secondary: const Icon(Icons.account_balance_wallet_outlined)), const SizedBox(height: 16), Text('Order total: ₹${widget.total.toStringAsFixed(0)}', style: const TextStyle(fontSize: 20, fontWeight: FontWeight.w900)), const SizedBox(height: 12), FilledButton(onPressed: () => showDialog(context: context, builder: (_) => AlertDialog(title: const Text('Checkout demo'), content: Text('Selected: $payment\nConnect the backend and payment gateway before accepting real orders.'), actions: [TextButton(onPressed: () => Navigator.popUntil(context, (r) => r.isFirst), child: const Text('Done'))])), child: const Text('Place order'))])); }

class WishlistPage extends StatelessWidget { const WishlistPage({super.key, required this.favourites, required this.onChanged}); final Set<Product> favourites; final VoidCallback onChanged; @override Widget build(BuildContext context) => Scaffold(appBar: AppBar(title: const Text('Wishlist')), body: favourites.isEmpty ? const EmptyState(icon: Icons.favorite_border, title: 'Save your favourites', subtitle: 'Tap the heart on any product.') : ListView(children: favourites.map((p) => ListTile(leading: CircleAvatar(backgroundColor: p.color, child: Text(p.emoji)), title: Text(p.name), subtitle: Text('₹${p.price.toStringAsFixed(0)}'))).toList())); }

class AccountPage extends StatelessWidget { const AccountPage({super.key}); @override Widget build(BuildContext context) => Scaffold(appBar: AppBar(title: const Text('My Account')), body: ListView(padding: const EdgeInsets.all(20), children: [const CircleAvatar(radius: 42, child: Icon(Icons.person, size: 44)), const SizedBox(height: 12), const Center(child: Text('Welcome to Easy Shopping', style: TextStyle(fontWeight: FontWeight.w800, fontSize: 18))), const SizedBox(height: 20), ListTile(leading: const Icon(Icons.login), title: const Text('Login / Sign up'), subtitle: const Text('Google or email sign-in setup required'), onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => const AuthDemoPage()))), const ListTile(leading: Icon(Icons.local_shipping_outlined), title: Text('My orders')), const ListTile(leading: Icon(Icons.location_on_outlined), title: Text('Saved addresses')), const ListTile(leading: Icon(Icons.help_outline), title: Text('Help & support')), const Padding(padding: EdgeInsets.only(top: 20), child: Text('Demo starter: account and order history become active after backend setup.', textAlign: TextAlign.center, style: TextStyle(color: Colors.black45, fontSize: 12)))])); }

class AuthDemoPage extends StatelessWidget { const AuthDemoPage({super.key}); @override Widget build(BuildContext context) => Scaffold(appBar: AppBar(title: const Text('Login / Sign up')), body: ListView(padding: const EdgeInsets.all(24), children: [const SizedBox(height: 24), const Icon(Icons.shopping_bag_rounded, color: brand, size: 64), const SizedBox(height: 14), const Text('Welcome back!', textAlign: TextAlign.center, style: TextStyle(fontSize: 26, fontWeight: FontWeight.w900)), const SizedBox(height: 24), const TextField(decoration: InputDecoration(labelText: 'Email address', prefixIcon: Icon(Icons.email_outlined), border: OutlineInputBorder()), keyboardType: TextInputType.emailAddress), const SizedBox(height: 12), const TextField(decoration: InputDecoration(labelText: 'Password', prefixIcon: Icon(Icons.lock_outline), border: OutlineInputBorder()), obscureText: true), const SizedBox(height: 16), FilledButton(onPressed: () => _info(context), child: const Text('Continue with email')), OutlinedButton.icon(onPressed: () => _info(context), icon: const Icon(Icons.g_mobiledata, size: 28), label: const Text('Continue with Google')), const SizedBox(height: 12), const Text('Authentication is a UI demo until Firebase is configured.', textAlign: TextAlign.center, style: TextStyle(color: Colors.black45, fontSize: 12))])); }
void _info(BuildContext context) => ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Connect Firebase Authentication to enable sign-in.')));

class AdminPage extends StatelessWidget { const AdminPage({super.key}); @override Widget build(BuildContext context) => Scaffold(appBar: AppBar(title: const Text('Admin Dashboard')), body: ListView(padding: const EdgeInsets.all(20), children: [Container(padding: const EdgeInsets.all(20), decoration: BoxDecoration(gradient: const LinearGradient(colors: [brand, Color(0xFFE86DB6)]), borderRadius: BorderRadius.circular(22)), child: const Column(crossAxisAlignment: CrossAxisAlignment.start, children: [Text('Store overview', style: TextStyle(color: Colors.white70)), SizedBox(height: 8), Text('Welcome, Admin 👋', style: TextStyle(color: Colors.white, fontWeight: FontWeight.w900, fontSize: 24)), Text('Demo dashboard preview', style: TextStyle(color: Colors.white70))])), const SizedBox(height: 16), const Row(children: [Expanded(child: StatCard(title: 'Products', value: '8', icon: Icons.inventory_2_outlined)), SizedBox(width: 10), Expanded(child: StatCard(title: 'Orders', value: '0', icon: Icons.receipt_long_outlined))]), const SizedBox(height: 18), AdminAction(icon: Icons.add_box_outlined, title: 'Add a product', subtitle: 'Create product listing', onTap: (c) => _adminInfo(c)), AdminAction(icon: Icons.edit_outlined, title: 'Manage products', subtitle: 'Edit prices, images and stock', onTap: (c) => _adminInfo(c)), AdminAction(icon: Icons.local_shipping_outlined, title: 'Manage orders', subtitle: 'View and update order status', onTap: (c) => _adminInfo(c)), AdminAction(icon: Icons.discount_outlined, title: 'Offers & coupons', subtitle: 'Create promotions', onTap: (c) => _adminInfo(c)), const Padding(padding: EdgeInsets.only(top: 18), child: Text('Important: this is a visual admin demo, not secured. Add Firebase admin authentication and server-side authorization before using it with real customer data.', style: TextStyle(color: Colors.deepOrange, fontSize: 12)))])); }
void _adminInfo(BuildContext context) => showDialog(context: context, builder: (_) => AlertDialog(title: const Text('Admin feature setup'), content: const Text('This screen is a starter preview. Connect Firestore and secure admin permissions to save real products and manage orders.'), actions: [TextButton(onPressed: () => Navigator.pop(context), child: const Text('OK'))]));
class StatCard extends StatelessWidget { const StatCard({super.key, required this.title, required this.value, required this.icon}); final String title, value; final IconData icon; @override Widget build(BuildContext context) => Container(padding: const EdgeInsets.all(16), decoration: BoxDecoration(color: Colors.white, borderRadius: BorderRadius.circular(18)), child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [Icon(icon, color: brand), const SizedBox(height: 10), Text(value, style: const TextStyle(fontSize: 24, fontWeight: FontWeight.w900)), Text(title, style: const TextStyle(color: Colors.black54))])); }
class AdminAction extends StatelessWidget { const AdminAction({super.key, required this.icon, required this.title, required this.subtitle, required this.onTap}); final IconData icon; final String title, subtitle; final void Function(BuildContext) onTap; @override Widget build(BuildContext context) => Card(color: Colors.white, child: ListTile(leading: CircleAvatar(backgroundColor: const Color(0xFFECE8FF), child: Icon(icon, color: brand)), title: Text(title, style: const TextStyle(fontWeight: FontWeight.w700)), subtitle: Text(subtitle), trailing: const Icon(Icons.chevron_right), onTap: () => onTap(context))); }
class EmptyState extends StatelessWidget { const EmptyState({super.key, required this.icon, required this.title, required this.subtitle}); final IconData icon; final String title, subtitle; @override Widget build(BuildContext context) => Center(child: Padding(padding: const EdgeInsets.all(32), child: Column(mainAxisSize: MainAxisSize.min, children: [Icon(icon, size: 64, color: brand), const SizedBox(height: 14), Text(title, style: const TextStyle(fontWeight: FontWeight.w900, fontSize: 20)), const SizedBox(height: 6), Text(subtitle, textAlign: TextAlign.center, style: const TextStyle(color: Colors.black54))]))); }
