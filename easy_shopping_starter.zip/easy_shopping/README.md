# Easy Shopping — Flutter starter

This starter includes a colorful shopping UI, sample product catalog, search/category filtering, cart, wishlist, checkout UI with COD/UPI selection, login/signup UI, and an admin dashboard preview.

## Important status
This is a **starter/demo**, not a production-ready store. Sign-in, online payments, order persistence, inventory, push notifications, and admin permissions are not connected yet. Do not accept real orders or customer data until those are implemented and tested.

## Run locally
1. Install Flutter SDK and Android Studio (Android) and/or Xcode on a Mac (iOS).
2. In this folder run:
   - `flutter pub get`
   - `flutter run`
3. For Android APK: `flutter build apk --release`
4. For Google Play upload bundle: `flutter build appbundle --release`
5. iOS build requires macOS/Xcode: `flutter build ios --release`

## Production setup still required
- Create a Firebase project and register Android/iOS apps.
- Add platform Firebase configuration (`google-services.json`, `GoogleService-Info.plist`) and FlutterFire setup.
- Enable Firebase Authentication providers: Google and Email/Password; configure OAuth client IDs and SHA fingerprints.
- Define Firestore collections and security rules for users, products, orders, addresses, coupons and inventory.
- Implement callable Cloud Functions/server endpoints for trusted order creation, price/stock validation, and order status changes.
- Add a payment gateway suitable for India. Never store UPI PIN, card numbers, or payment credentials in Firestore. Verify payment status on the server.
- Protect admin access using verified roles/custom claims and server-side authorization; hiding admin UI is not security.
- Add privacy policy, terms, shipping/returns/refunds, contact details, data deletion process, app icons/screenshots, age/content declarations and store metadata.
- Test on physical Android and iOS devices before store submission.

## Branding decisions
- App name: Easy Shopping
- Model: single-store (your products only)
- Logo direction: modern shopping-cart mark
- Theme: bright multicolour/purple-pink gradient accents
- Payments planned: Cash on Delivery + UPI/online gateway
